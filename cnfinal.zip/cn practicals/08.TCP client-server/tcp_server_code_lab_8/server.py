import socket

HOST = '127.0.0.1'   # Localhost
PORT = 5000          # Choose any free port

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind((HOST, PORT))
server_socket.listen(1)

print("Server is waiting for a connection...")

connection, address = server_socket.accept()
print(f"Connected to: {address}")

data = connection.recv(1024).decode()
print("Client says:", data)

reply = "Message received by server"
connection.send(reply.encode())

connection.close()
server_socket.close()
