# client.py
import socket

HOST = "127.0.0.1"
PORT = 5005

filename = input("Enter filename to download: ")

s = socket.socket()
s.connect((HOST, PORT))

s.send(filename.encode())

resp = s.recv(1024)

if resp != b"OK":
    print("Server error:", resp.decode())
    s.close()
    exit()

with open("downloaded_" + filename, "wb") as f:
    while True:
        data = s.recv(4096)
        if not data:
            break
        f.write(data)

print("File downloaded successfully.")
s.close()
