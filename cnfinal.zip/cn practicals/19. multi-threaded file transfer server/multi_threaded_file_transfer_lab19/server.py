# server.py
import socket
import threading
import os

HOST = "0.0.0.0"
PORT = 5005
FILES_FOLDER = "files"

os.makedirs(FILES_FOLDER, exist_ok=True)

def handle_client(conn, addr):
    print(f"[+] Client connected: {addr}")

    filename = conn.recv(1024).decode().strip()
    filepath = os.path.join(FILES_FOLDER, filename)

    if not os.path.exists(filepath):
        conn.send(b"ERROR: File not found")
        conn.close()
        print(f"[-] File not found for {addr}")
        return

    conn.send(b"OK")
    with open(filepath, "rb") as f:
        while True:
            chunk = f.read(4096)
            if not chunk:
                break
            conn.sendall(chunk)

    conn.close()
    print(f"[+] Sent '{filename}' to {addr}")


def start_server():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind((HOST, PORT))
    s.listen(10)
    print(f"Server running on {HOST}:{PORT}")

    while True:
        conn, addr = s.accept()
        thread = threading.Thread(target=handle_client, args=(conn, addr), daemon=True)
        thread.start()


if __name__ == "__main__":
    start_server()
