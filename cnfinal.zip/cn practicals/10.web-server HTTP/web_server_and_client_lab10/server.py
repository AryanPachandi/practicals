# server.py
from flask import Flask, request, jsonify, make_response
from datetime import datetime

app = Flask(__name__)

def pretty_log_separator():
    print("=" * 70)

def log_request():
    pretty_log_separator()
    print("Incoming Request:")
    print(f" Time        : {datetime.utcnow().isoformat()}Z")
    print(f" Remote Addr : {request.remote_addr}")
    print(f" Method      : {request.method}")
    print(f" Path        : {request.path}")
    qs = request.query_string.decode() or "-"
    print(f" QueryString : {qs}")
    print(" Headers:")
    for k, v in request.headers.items():
        print(f"   {k}: {v}")
    data = request.get_data(as_text=True)
    if data:
        print(" Body:")
        for line in data.splitlines():
            print("   " + line)
    else:
        print(" Body: -")
    pretty_log_separator()

@app.route("/", methods=["GET"])
def index():
    log_request()
    payload = {"message": "Hello from Flask server (GET)", "time": datetime.utcnow().isoformat() + "Z"}
    resp = make_response(jsonify(payload), 200)
    resp.headers["X-Server-Note"] = "FlaskTestServer"
    return resp

@app.route("/echo", methods=["POST"])
def echo():
    log_request()
    try:
        body_json = request.get_json(force=False)
    except Exception:
        body_json = None
    if body_json is not None:
        received = body_json
    else:
        received = request.get_data(as_text=True)
    response_data = {
        "received": received,
        "received_type": type(received).__name__,
        "message": "Echo from server"
    }
    resp = make_response(jsonify(response_data), 201)
    resp.headers["X-Echo"] = "true"
    return resp

@app.route("/headers", methods=["GET"])
def headers_only():
    log_request()
    return jsonify({k:v for k,v in request.headers.items()})

if __name__ == "__main__":
    print("Starting Flask server on http://127.0.0.1:5000")
    app.run(host="127.0.0.1", port=5000, debug=False)
