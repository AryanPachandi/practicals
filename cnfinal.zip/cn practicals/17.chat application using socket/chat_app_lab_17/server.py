

# chat_server.py
import socket
import threading

HOST = "0.0.0.0"
PORT = 6000
BUFSIZE = 4096

clients = {}  # socket -> username
lock = threading.Lock()

def broadcast(msg, exclude_sock=None):
    """Send msg (bytes) to all clients except exclude_sock."""
    with lock:
        dead = []
        for sock in list(clients):
            if sock is exclude_sock:
                continue
            try:
                sock.sendall(msg)
            except Exception:
                dead.append(sock)
        for d in dead:
            remove_client(d)

def remove_client(sock):
    with lock:
        name = clients.pop(sock, None)
    try:
        sock.close()
    except:
        pass
    if name:
        broadcast(f"[SERVER] {name} has left the chat.\n".encode())

def handle_client(conn, addr):
    try:
        conn.sendall(b"Welcome! Send your username on the first line:\n")
        uname = conn.recv(BUFSIZE).decode(errors="ignore").strip()
        if not uname:
            conn.close(); return
        with lock:
            clients[conn] = uname
        print(f"{addr} -> {uname} connected.")
        broadcast(f"[SERVER] {uname} has joined the chat.\n".encode(), exclude_sock=conn)
        conn.sendall(b"[SERVER] You are connected. Type messages and press Enter.\n")
        while True:
            data = conn.recv(BUFSIZE)
            if not data:
                break
            text = data.decode(errors="ignore").strip()
            if text.lower() == "/quit":
                break
            # Simple private message: /pm recipient message
            if text.startswith("/pm "):
                parts = text.split(" ", 2)
                if len(parts) >= 3:
                    recipient, message = parts[1], parts[2]
                    sent = False
                    with lock:
                        for s, u in clients.items():
                            if u == recipient:
                                try:
                                    s.sendall(f"[PM from {uname}] {message}\n".encode())
                                    sent = True
                                except:
                                    pass
                    if not sent:
                        conn.sendall(f"[SERVER] User '{recipient}' not found.\n".encode())
                else:
                    conn.sendall(b"[SERVER] Usage: /pm <username> <message>\n")
                continue
            # Broadcast normal message
            broadcast(f"{uname}: {text}\n".encode(), exclude_sock=None)
    except Exception as e:
        print("Client handler error:", e)
    finally:
        remove_client(conn)
        print(f"{addr} disconnected.")

def start():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind((HOST, PORT))
    sock.listen(50)
    print(f"Chat server listening on {HOST}:{PORT}")
    try:
        while True:
            conn, addr = sock.accept()
            t = threading.Thread(target=handle_client, args=(conn, addr), daemon=True)
            t.start()
    except KeyboardInterrupt:
        print("Shutting down server.")
    finally:
        sock.close()
        with lock:
            for s in list(clients):
                try: s.close()
                except: pass
            clients.clear()

if __name__ == "__main__":
    start()
