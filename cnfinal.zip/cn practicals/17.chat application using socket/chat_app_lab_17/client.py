# chat_client.py
import socket
import threading
import sys

HOST = "127.0.0.1"   # change to server IP if needed
PORT = 6000
BUFSIZE = 4096

def recv_loop(sock):
    try:
        while True:
            data = sock.recv(BUFSIZE)
            if not data:
                print("[DEBUG] Server closed connection.")
                break
            # print incoming server/client messages
            print(data.decode(errors="ignore"), end="")
    except Exception as e:
        print("[DEBUG] Receive error:", e)
    finally:
        try: sock.close()
        except: pass
        sys.exit(0)

def main():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.connect((HOST, PORT))
    except Exception as e:
        print("Unable to connect to server:", e)
        return
    # start receiver thread
    t = threading.Thread(target=recv_loop, args=(sock,), daemon=True)
    t.start()

    # send username as first line
    username = input("Choose a username: ").strip()
    if not username:
        print("Username required.")
        sock.close()
        return
    sock.sendall((username + "\n").encode())

    print("You can now type messages. Commands: /quit to exit, /pm <user> <msg> for private message.")
    try:
        while True:
            line = input()
            if not line:
                continue
            if line.strip().lower() == "/quit":
                sock.sendall(b"/quit\n")
                break
            # send message
            sock.sendall((line + "\n").encode())
    except KeyboardInterrupt:
        sock.sendall(b"/quit\n")
    finally:
        sock.close()
        print("Disconnected.")

if __name__ == "__main__":
    main()
