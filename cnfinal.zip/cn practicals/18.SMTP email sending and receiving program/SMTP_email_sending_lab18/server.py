# smtp_server.py
import socket
import threading

HOST = "0.0.0.0"
PORT = 2525

def handle_client(conn, addr):
    print(f"[+] Client connected: {addr}")
    conn.send(b"220 Simple SMTP Server Ready\r\n")

    data_mode = False
    email_buffer = []

    while True:
        cmd = conn.recv(1024)
        if not cmd:
            break

        text = cmd.decode().strip()
        print("CMD:", text)

        if data_mode:
            if text == ".":
                conn.send(b"250 Message accepted\r\n")
                print("\n=== Email Received ===")
                print("\n".join(email_buffer))
                print("======================\n")
                data_mode = False
                email_buffer.clear()
            else:
                email_buffer.append(text)
            continue

        if text.startswith("HELO"):
            conn.send(b"250 Hello client\r\n")

        elif text.startswith("MAIL FROM"):
            conn.send(b"250 OK sender\r\n")

        elif text.startswith("RCPT TO"):
            conn.send(b"250 OK receiver\r\n")

        elif text == "DATA":
            conn.send(b"354 End data with <CR><LF>.<CR><LF>\r\n")
            data_mode = True

        elif text == "QUIT":
            conn.send(b"221 Bye\r\n")
            break

        else:
            conn.send(b"500 Unknown command\r\n")

    conn.close()
    print(f"[-] Client disconnected: {addr}")

def start():
    s = socket.socket()
    s.bind((HOST, PORT))
    s.listen(5)
    print(f"SMTP Server running on port {PORT}...")

    while True:
        conn, addr = s.accept()
        threading.Thread(target=handle_client, args=(conn, addr), daemon=True).start()

if __name__ == "__main__":
    start()
