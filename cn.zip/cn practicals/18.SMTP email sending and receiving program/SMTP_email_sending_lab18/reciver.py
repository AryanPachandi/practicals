# smtp_client.py
import socket

SERVER_HOST = "127.0.0.1"
SERVER_PORT = 2525

def send(sock, cmd):
    sock.send((cmd + "\r\n").encode())
    print(">>>", cmd)
    print("<<<", sock.recv(1024).decode())

s = socket.socket()
s.connect((SERVER_HOST, SERVER_PORT))

print("<<<", s.recv(1024).decode())

send(s, "HELO client")
send(s, "MAIL FROM:<sender@example.com>")
send(s, "RCPT TO:<receiver@example.com>")
send(s, "DATA")

# email content ends with a single '.'
email = [
    "Subject: Test SMTP Mail",
    "This is a test email sent using socket programming.",
    "Bye!",
    "."
]

for line in email:
    send(s, line)

send(s, "QUIT")
s.close()
