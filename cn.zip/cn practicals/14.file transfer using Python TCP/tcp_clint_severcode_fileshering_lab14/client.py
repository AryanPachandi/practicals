import socket

HOST = "127.0.0.1"
PORT = 5001
OUT_FILE = "received.txt"

with socket.socket() as s:
    s.connect((HOST, PORT))
    data = b""

    while True:
        part = s.recv(4096)
        if not part:
            break
        data += part

# Save the file
with open(OUT_FILE, "wb") as f:
    f.write(data)

print("File received and saved as:", OUT_FILE)
print("\n----- File Content -----")

try:
    # Try printing as text
    print(data.decode())
except:
    # If binary (image, pdf, etc.), print hex preview
    print("Binary file detected, showing hex preview:")
    print(data[:200].hex(), "...")   # first 200 bytes

