import socket

HOST = "0.0.0.0"
PORT = 5001
FILE = "data.txt"   # file to send

with socket.socket() as s:
    s.bind((HOST, PORT))
    s.listen(1)
    print("Server ready...")

    conn, addr = s.accept()
    print("Client connected:", addr)

    with open(FILE, "rb") as f:
        data = f.read()

    conn.sendall(data)
    print("File sent.")
    conn.close()
