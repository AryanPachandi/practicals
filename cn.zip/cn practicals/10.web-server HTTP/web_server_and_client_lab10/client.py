# client.py
import requests
import json
from datetime import datetime

BASE = "http://127.0.0.1:5000"

def pretty(d):
    try:
        return json.dumps(d, indent=2)
    except Exception:
        return str(d)

def print_sep():
    print("-" * 70)

def do_get():
    url = f"{BASE}/"
    headers = {
        "User-Agent": "PythonClient/1.0",
        "X-Client-Note": "TestingGET"
    }
    print_sep()
    print(f"[{datetime.utcnow().isoformat()}Z] Sending GET Request -> {url}")
    r = requests.get(url, headers=headers, params={"q":"test"})
    print(f"Received GET response - status: {r.status_code}")
    print("Response headers:")
    for k, v in r.headers.items():
        print(f"  {k}: {v}")
    print("Response body (text):")
    print(r.text)
    print("Raw elapsed (sec):", r.elapsed.total_seconds())
    print_sep()

def do_post_json():
    url = f"{BASE}/echo"
    headers = {
        "User-Agent": "PythonClient/1.0",
        "Content-Type": "application/json",
        "X-Client-Note": "TestingPOST"
    }
    payload = {"name": "anushka", "action": "test", "numbers": [1,2,3]}
    print_sep()
    print(f"[{datetime.utcnow().isoformat()}Z] Sending POST Request (JSON) -> {url}")
    print("Request headers:")
    for k,v in headers.items():
        print(f"  {k}: {v}")
    print("Request body:")
    print(pretty(payload))
    r = requests.post(url, headers=headers, json=payload)
    print(f"Received POST response - status: {r.status_code}")
    print("Response headers:")
    for k, v in r.headers.items():
        print(f"  {k}: {v}")
    print("Response body (json):")
    try:
        print(pretty(r.json()))
    except Exception:
        print(r.text)
    print("Raw elapsed (sec):", r.elapsed.total_seconds())
    print_sep()

def do_post_text():
    url = f"{BASE}/echo"
    headers = {
        "User-Agent": "PythonClient/1.0",
        "Content-Type": "text/plain",
    }
    data = "this is plain text body"
    print_sep()
    print(f"[{datetime.utcnow().isoformat()}Z] Sending POST Request (text) -> {url}")
    print("Request headers:")
    for k,v in headers.items():
        print(f"  {k}: {v}")
    print("Request body:")
    print(data)
    r = requests.post(url, headers=headers, data=data)
    print(f"Received POST response - status: {r.status_code}")
    print("Response headers:")
    for k, v in r.headers.items():
        print(f"  {k}: {v}")
    try:
        print("Response JSON:")
        print(pretty(r.json()))
    except Exception:
        print("Response text:")
        print(r.text)
    print("Raw elapsed (sec):", r.elapsed.total_seconds())
    print_sep()

if __name__ == "__main__":
    do_get()
    do_post_json()
    do_post_text()
