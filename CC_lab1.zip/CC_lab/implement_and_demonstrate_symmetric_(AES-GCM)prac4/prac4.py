import os
import base64
from typing import Tuple
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import serialization, hashes


# ---------------------------
# AES-GCM (symmetric helpers)
# ---------------------------
def aes_gen_key() -> bytes:
    """Generate a random 256-bit AES key for AES-GCM."""
    return AESGCM.generate_key(bit_length=256)


def aes_encrypt(key: bytes, plaintext: str) -> Tuple[str, str]:
    """
    Encrypt plaintext with AES-GCM.
    Returns (ciphertext_b64, nonce_b64).
    """
    aesgcm = AESGCM(key)
    nonce = os.urandom(12)  # 96-bit nonce recommended for GCM
    ct = aesgcm.encrypt(nonce, plaintext.encode("utf-8"), associated_data=None)
    return base64.b64encode(ct).decode("ascii"), base64.b64encode(nonce).decode("ascii")


def aes_decrypt(key: bytes, ciphertext_b64: str, nonce_b64: str) -> str:
    """Decrypt AES-GCM ciphertext (both inputs are base64 strings)."""
    aesgcm = AESGCM(key)
    ciphertext = base64.b64decode(ciphertext_b64)
    nonce = base64.b64decode(nonce_b64)
    pt = aesgcm.decrypt(nonce, ciphertext, associated_data=None)
    return pt.decode("utf-8")


# ---------------------------
# RSA (asymmetric helpers)
# ---------------------------
def rsa_gen_keys(key_size: int = 2048) -> Tuple[rsa.RSAPrivateKey, rsa.RSAPublicKey]:
    """Generate an RSA private/public key pair."""
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=key_size
    )
    public_key = private_key.public_key()
    return private_key, public_key


def rsa_encrypt(public_key: rsa.RSAPublicKey, plaintext: str) -> str:
    """
    Encrypt plaintext with RSA-OAEP (SHA-256).
    Returns base64-encoded ciphertext.
    """
    ciphertext = public_key.encrypt(
        plaintext.encode("utf-8"),
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None
        )
    )
    return base64.b64encode(ciphertext).decode("ascii")


def rsa_decrypt(private_key: rsa.RSAPrivateKey, ciphertext_b64: str) -> str:
    """Decrypt RSA-OAEP ciphertext (base64 string)."""
    ciphertext = base64.b64decode(ciphertext_b64)
    plaintext = private_key.decrypt(
        ciphertext,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None
        )
    )
    return plaintext.decode("utf-8")


# ---------------------------
# RSA serialization helpers
# ---------------------------
def serialize_private_key(private_key: rsa.RSAPrivateKey, password: bytes | None = None) -> bytes:
    """
    Serialize private key to PEM. If password is provided, it will be encrypted using best available algorithm.
    """
    encryption = (
        serialization.BestAvailableEncryption(password) if password else serialization.NoEncryption()
    )
    pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=encryption
    )
    return pem


def serialize_public_key(public_key: rsa.RSAPublicKey) -> bytes:
    """Serialize public key to PEM (SubjectPublicKeyInfo)."""
    pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )
    return pem


def load_private_key(pem_data: bytes, password: bytes | None = None) -> rsa.RSAPrivateKey:
    """Load a PEM-encoded private key (optionally password protected)."""
    return serialization.load_pem_private_key(pem_data, password=password)


def load_public_key(pem_data: bytes) -> rsa.RSAPublicKey:
    """Load a PEM-encoded public key."""
    return serialization.load_pem_public_key(pem_data)


# ---------------------------
# Demo / example usage
# ---------------------------
if __name__ == "__main__":
    # AES demo
    key = aes_gen_key()
    # WARNING: printing keys is for demo only. Remove in production.
    print("AES key (base64)  :", base64.b64encode(key).decode("ascii"))

    ct_b64, nonce_b64 = aes_encrypt(key, "Hello AES-GCM world")
    print("AES ciphertext    :", ct_b64)
    print("AES nonce         :", nonce_b64)

    pt = aes_decrypt(key, ct_b64, nonce_b64)
    print("AES decrypted     :", pt)

    # RSA demo
    priv, pub = rsa_gen_keys(2048)
    # Serialize keys (for storage or transport) - do not print in prod
    pub_pem = serialize_public_key(pub)
    priv_pem = serialize_private_key(priv, password=None)
    print("\nRSA public key PEM:\n", pub_pem.decode("utf-8"))
    # We encrypt a short message (RSA can only encrypt up to key_size-dependent length minus OAEP overhead)
    rsa_ct = rsa_encrypt(pub, "Hello RSA-OAEP world")
    print("RSA ciphertext (base64):", rsa_ct)
    rsa_pt = rsa_decrypt(priv, rsa_ct)
    print("RSA decrypted          :", rsa_pt)

    # Hybrid example (recommended pattern):
    # 1) Generate random AES key
    # 2) Encrypt data with AES-GCM
    # 3) Encrypt AES key with RSA public key
    # 4) Send rsa_encrypted_aes_key + aes_ciphertext + nonce
    aes_key = aes_gen_key()
    data_ct, data_nonce = aes_encrypt(aes_key, "Secret document contents")
    enc_aes_key = rsa_encrypt(pub, base64.b64encode(aes_key).decode("ascii"))
    print("\nHybrid envelope:")
    print("Encrypted AES key (RSA, base64) :", enc_aes_key)
    print("Encrypted data (AES-GCM, base64) :", data_ct)
    print("Nonce (base64)                   :", data_nonce)

    # To decrypt hybrid:
    dec_aes_key_b64 = rsa_decrypt(priv, enc_aes_key)
    dec_aes_key = base64.b64decode(dec_aes_key_b64)
    recovered = aes_decrypt(dec_aes_key, data_ct, data_nonce)
    print("Hybrid recovered plaintext       :", recovered)
