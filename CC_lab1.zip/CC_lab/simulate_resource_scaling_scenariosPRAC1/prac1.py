import threading
import multiprocessing
import time


def cpu_task(n: int) -> int:
    """Count primes < n (CPU-bound). Returns the number found."""
    count = 0
    for i in range(2, n):
        prime = True
        # check divisibility up to sqrt(i)
        limit = int(i ** 0.5) + 1
        for j in range(2, limit):
            if i % j == 0:
                prime = False
                break
        if prime:
            count += 1
    return count


def vertical_scaling_simulation(thread_count: int, task_size: int) -> None:
    """Run cpu_task concurrently using threads and measure elapsed time."""
    threads = []
    start_time = time.time()

    for _ in range(thread_count):
        t = threading.Thread(target=cpu_task, args=(task_size,))
        threads.append(t)
        t.start()

    for t in threads:
        t.join()

    end_time = time.time()
    print(f"[Vertical Scaling] Threads: {thread_count}, Time taken: {end_time - start_time:.2f}s")


def horizontal_scaling_simulation(process_count: int, task_size: int) -> None:
    """Run cpu_task concurrently using processes and measure elapsed time."""
    processes = []
    start_time = time.time()

    for _ in range(process_count):
        p = multiprocessing.Process(target=cpu_task, args=(task_size,))
        processes.append(p)
        p.start()

    for p in processes:
        p.join()

    end_time = time.time()
    print(f"[Horizontal Scaling] Processes: {process_count}, Time taken: {end_time - start_time:.2f}s")


if __name__ == "__main__":
    # Keep the task small enough so the demo finishes quickly on most machines.
    TASK_SIZE = 20000

    print("Simulating Vertical Scaling (Thread-based)...")
    for threads in [1, 2, 4]:
        vertical_scaling_simulation(threads, TASK_SIZE)

    print("\nSimulating Horizontal Scaling (Process-based)...")
    for processes in [1, 2, 4]:
        horizontal_scaling_simulation(processes, TASK_SIZE)
