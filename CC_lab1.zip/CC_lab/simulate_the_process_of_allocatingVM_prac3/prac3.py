import threading
import time
import random
from dataclasses import dataclass, field
from typing import List, Dict, Tuple


@dataclass
class Host:
    id: int
    cpu_capacity: int
    mem_capacity: int
    cpu_used: int = 0
    mem_used: int = 0
    lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    def can_place(self, vm: "VMRequest") -> bool:
        # check capacity without modifying state
        return (self.cpu_used + vm.cpus <= self.cpu_capacity) and \
               (self.mem_used + vm.mems <= self.mem_capacity)

    def place(self, vm: "VMRequest") -> None:
        # called under lock
        self.cpu_used += vm.cpus
        self.mem_used += vm.mems

    def remove(self, vm: "VMRequest") -> None:
        # called under lock
        self.cpu_used -= vm.cpus
        self.mem_used -= vm.mems
        # safety: never go negative
        if self.cpu_used < 0:
            self.cpu_used = 0
        if self.mem_used < 0:
            self.mem_used = 0

    def try_place(self, vm: "VMRequest") -> bool:
        """Atomically check & place a VM if possible. Returns True if placed."""
        with self.lock:
            if self.can_place(vm):
                self.place(vm)
                return True
            return False

    def release(self, vm: "VMRequest") -> None:
        """Atomically remove VM resources."""
        with self.lock:
            self.remove(vm)


@dataclass
class VMRequest:
    id: int
    cpus: int
    mems: int
    duration: float  # seconds


class Scheduler:
    def __init__(self, hosts: List[Host]):
        self.hosts: List[Host] = hosts
        # placed: vm_id -> (VMRequest, Host)
        self.placed: Dict[int, Tuple[VMRequest, Host]] = {}
        self.lock = threading.Lock()  # protects self.placed

    def schedule_vm(self, vm: VMRequest) -> bool:
        """Try to place VM on any host. Returns True if placed."""
        for h in self.hosts:
            if h.try_place(vm):
                with self.lock:
                    self.placed[vm.id] = (vm, h)
                print(f"Placed VM {vm.id} on Host {h.id} "
                      f"(CPU: {h.cpu_used}/{h.cpu_capacity}, MEM: {h.mem_used}/{h.mem_capacity})")
                t = threading.Thread(target=self.run_vm, args=(vm, h), daemon=True)
                t.start()
                return True

        print(f"Failed to place VM {vm.id} (no available capacity)")
        return False

    def run_vm(self, vm: VMRequest, host: Host) -> None:
        """Simulate VM running for vm.duration, then remove it."""
        try:
            time.sleep(vm.duration)
        finally:
            # Ensure removal even if sleep is interrupted (rare)
            host.release(vm)
            with self.lock:
                # safe deletion if present
                if vm.id in self.placed:
                    del self.placed[vm.id]
            print(f"VM {vm.id} finished on Host {host.id} "
                  f"(CPU: {host.cpu_used}/{host.cpu_capacity}, MEM: {host.mem_used}/{host.mem_capacity})")

    def active_count(self) -> int:
        with self.lock:
            return len(self.placed)


def demo():
    # three hosts with 16 CPU units and 32 memory units each
    hosts = [Host(i, cpu_capacity=16, mem_capacity=32) for i in range(3)]
    sched = Scheduler(hosts)

    # create and try to schedule 10 VMs with random sizes/durations
    for i in range(10):
        vm = VMRequest(
            id=i + 1,
            cpus=random.choice([1, 2, 4]),
            mems=random.choice([1, 2, 4, 8]),
            duration=random.uniform(2.0, 6.0)
        )
        sched.schedule_vm(vm)
        # stagger arrival times
        time.sleep(random.uniform(0.2, 1.0))

    # wait until all placed VMs finish
    while sched.active_count() > 0:
        time.sleep(0.5)

    print("All VMs completed execution.")


if __name__ == "__main__":
    demo()
