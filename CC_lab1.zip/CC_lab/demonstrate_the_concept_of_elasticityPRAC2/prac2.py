import threading
import time
import queue


def process_task(task_id: int) -> None:
    """Simulate doing work for a task."""
    print(f"[{time.strftime('%H:%M:%S')}] Processing Task {task_id}")
    time.sleep(1)  # simulate work
    print(f"[{time.strftime('%H:%M:%S')}] Task {task_id} completed")


def worker(task_queue: queue.Queue, thread_id: int) -> None:
    """
    Worker loop: pull tasks from the queue and process them.
    Exits when queue.get(timeout=...) raises queue.Empty.
    """
    while True:
        try:
            task_id = task_queue.get(timeout=2)  # wait for a task
        except queue.Empty:
            print(f"[Thread-{thread_id}] no more tasks. Exiting...")
            break

        try:
            print(f"[Thread-{thread_id}] picked Task-{task_id}")
            process_task(task_id)
        finally:
            task_queue.task_done()


def simulate_elasticity() -> None:
    """
    Demonstrates elastic scaling: start with a small worker pool,
    then add tasks and more workers to absorb the load.
    """
    task_queue = queue.Queue()

    # initial workload
    for i in range(5):
        task_queue.put(i)

    # start with 2 workers
    initial_threads = 2
    threads = []
    print("\nStarting with 2 worker threads...\n")
    for t_id in range(initial_threads):
        t = threading.Thread(target=worker, args=(task_queue, t_id))
        t.start()
        threads.append(t)

    # let them work a bit
    time.sleep(3)

    # workload increases: add more tasks
    print("\nWorkload increased! Adding more tasks and more threads...\n")
    for i in range(5, 15):
        task_queue.put(i)

    # add more workers to scale out (threads 2,3,4)
    for t_id in range(2, 5):
        t = threading.Thread(target=worker, args=(task_queue, t_id))
        t.start()
        threads.append(t)

    # wait until all tasks are processed
    task_queue.join()

    # wait for worker threads to exit
    for t in threads:
        t.join()

    print("\nAll tasks completed. Resources scaled elastically.\n")


if __name__ == "__main__":
    simulate_elasticity()
