import threading
import time
import random


class CloudInstance:
    def __init__(self, name: str):
        self.name = name
        self._is_active = True
        self._lock = threading.Lock()

    def is_active(self) -> bool:
        with self._lock:
            return self._is_active

    def set_active(self, active: bool) -> None:
        with self._lock:
            self._is_active = active

    def process_request(self, request_id: str) -> None:
        """
        Process a request. Raises RuntimeError if instance is down.
        Simulates some processing delay.
        """
        if not self.is_active():
            raise RuntimeError(f"{self.name} instance is DOWN in cloud!")
        # simulate processing time
        time.sleep(random.uniform(0.05, 0.2))
        print(f"[{time.strftime('%H:%M:%S')}] {self.name} handled request {request_id}")


class CloudFailoverSystem:
    def __init__(self, primary: CloudInstance, backup: CloudInstance):
        self.primary = primary
        self.backup = backup
        self.active_instance = primary
        self._lock = threading.Lock()

    def send_request(self, request_id: str) -> None:
        """
        Sends a request to the currently-active instance. On failure,
        performs failover and retries once on the backup.
        """
        with self._lock:
            try:
                self.active_instance.process_request(request_id)
                return
            except Exception as e:
                print(f"[{time.strftime('%H:%M:%S')}] Cloud Failure detected: {e}")
                self.failover()

        # Retry outside the same lock so processing can run concurrently on the backup
        try:
            self.active_instance.process_request(request_id)
        except Exception as e2:
            print(f"[{time.strftime('%H:%M:%S')}] Both cloud instances failed! Dropping request {request_id} ({e2})")

    def failover(self) -> None:
        """Switch active_instance to the other instance."""
        if self.active_instance == self.primary:
            print(f"[{time.strftime('%H:%M:%S')}] Redirecting traffic to BACKUP cloud instance...")
            self.active_instance = self.backup
        else:
            print(f"[{time.strftime('%H:%M:%S')}] Redirecting traffic back to PRIMARY cloud instance...")
            self.active_instance = self.primary


def client_requests(system: CloudFailoverSystem, client_id: int, total: int = 5) -> None:
    """
    Each client generates `total` requests. Randomly simulate a primary outage
    by flipping primary to down (rare).
    """
    for i in range(1, total + 1):
        request_id = f"client{client_id}-Req{i}"

        # small chance to simulate a sudden primary failure before sending request
        if random.random() < 0.15:
            print(f"[{time.strftime('%H:%M:%S')}] Simulating PRIMARY outage (client {client_id})")
            system.primary.set_active(False)

        system.send_request(request_id)

        # small chance to simulate backup failure as well
        if random.random() < 0.02:
            print(f"[{time.strftime('%H:%M:%S')}] Simulating BACKUP outage (client {client_id})")
            system.backup.set_active(False)

        time.sleep(random.uniform(0.1, 0.4))


def cloud_health_monitor(system: CloudFailoverSystem, check_interval: float = 2.0) -> None:
    """
    Monitor thread: if primary is down, restore it after a short simulated repair time.
    """
    while True:
        time.sleep(check_interval)
        if not system.primary.is_active():
            print(f"[{time.strftime('%H:%M:%S')}] Cloud Monitor: Detected PRIMARY down. Restoring PRIMARY instance...")
            # simulate repair time
            time.sleep(1.0)
            system.primary.set_active(True)
            print(f"[{time.strftime('%H:%M:%S')}] Cloud Monitor: PRIMARY restored.")


if __name__ == "__main__":
    random.seed(42)  # keep behavior repeatable for testing/demos

    primary_instance = CloudInstance("PRIMARY")
    backup_instance = CloudInstance("BACKUP")
    system = CloudFailoverSystem(primary_instance, backup_instance)

    # Start health monitor (daemon so it won't block program exit)
    monitor_thread = threading.Thread(target=cloud_health_monitor, args=(system,), daemon=True)
    monitor_thread.start()

    # Launch a few client threads
    clients = []
    for cid in range(1, 4):
        t = threading.Thread(target=client_requests, args=(system, cid, 8))
        clients.append(t)
        t.start()

    # Wait for clients to finish
    for t in clients:
        t.join()

    print("\nCloud Failover Simulation Complete")
