import subprocess

# CONFIG
num_containers = 3
image_name = "nginx"
base_name = "scalable_container"

print("Stopping and removing old containers...\n")

for i in range(1, num_containers + 1):
    container_name = f"{base_name}_{i}"
    subprocess.run(["docker", "stop", container_name], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    subprocess.run(["docker", "rm", container_name], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    print(f"Removed container: {container_name}")

print("\nCleanup complete.\n")
print(f"Deploying {num_containers} containers using image '{image_name}'...\n")

# Pull image
subprocess.run(["docker", "pull", image_name])

# Deploy new containers
for i in range(1, num_containers + 1):
    container_name = f"{base_name}_{i}"
    subprocess.run(["docker", "run", "-d", "--name", container_name, image_name])
    print(f"Started container: {container_name}")

print("\nAll containers deployed successfully.\n")
print("Currently running containers:\n")

subprocess.run(["docker", "ps"])
