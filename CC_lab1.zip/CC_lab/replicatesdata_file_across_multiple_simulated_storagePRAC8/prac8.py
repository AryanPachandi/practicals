import os
import shutil
import hashlib
from typing import List, Dict


class DataReplicationService:
    def __init__(self, source_file: str, node_dirs: List[str]):
        self.source_file = source_file
        self.node_dirs = node_dirs
        self.filename = os.path.basename(source_file)

    def replicate(self) -> None:
        """Copy the source file to every node directory (creates dirs if needed)."""
        if not os.path.exists(self.source_file):
            raise FileNotFoundError(f"Source file {self.source_file} not found.")

        for node in self.node_dirs:
            os.makedirs(node, exist_ok=True)
            dest_path = os.path.join(node, self.filename)
            shutil.copy2(self.source_file, dest_path)
            print(f"Replicated to {dest_path}")

    def verify_integrity(self) -> Dict[str, str]:
        """
        Verify SHA-256 integrity of each replicated file against the source file.
        Returns a mapping node -> status (OK | CORRUPTED | MISSING).
        """
        if not os.path.exists(self.source_file):
            raise FileNotFoundError(f"Source file {self.source_file} not found for verification.")

        original_hash = self.get_file_hash(self.source_file)
        results: Dict[str, str] = {}

        for node in self.node_dirs:
            node_file = os.path.join(node, self.filename)
            if not os.path.exists(node_file):
                results[node] = "MISSING"
            else:
                node_hash = self.get_file_hash(node_file)
                results[node] = "OK" if node_hash == original_hash else "CORRUPTED"

        return results

    def get_file_hash(self, filepath: str) -> str:
        """Compute SHA-256 hex digest of a file."""
        hasher = hashlib.sha256()
        with open(filepath, "rb") as f:
            while chunk := f.read(8192):
                hasher.update(chunk)
        return hasher.hexdigest()

    def simulate_corruption(self, node: str) -> None:
        """Append garbage to the file on a node to simulate corruption."""
        file_path = os.path.join(node, self.filename)
        if os.path.exists(file_path):
            with open(file_path, "a", encoding="utf-8", errors="ignore") as f:
                f.write("\nCORRUPTED DATA\n")
            print(f"File in node '{node}' has been corrupted.")
        else:
            print(f"File not found in node '{node}' to corrupt.")

    def restore_node_from_source(self, node: str) -> None:
        """Restore a node's copy from the source file (overwrite)."""
        if not os.path.exists(self.source_file):
            raise FileNotFoundError(f"Source file {self.source_file} not found for restore.")
        os.makedirs(node, exist_ok=True)
        dest_path = os.path.join(node, self.filename)
        shutil.copy2(self.source_file, dest_path)
        print(f"Restored {dest_path} from source.")


if __name__ == "__main__":
    # Demo: create a small source file, replicate it, verify, corrupt node2, verify again and restore
    source_file = "example_data.txt"
    with open(source_file, "w", encoding="utf-8") as f:
        f.write("This is the original data file.\n")

    nodes = ["node1", "node2", "node3"]
    service = DataReplicationService(source_file, nodes)

    print("\nReplicating file to nodes...")
    service.replicate()

    print("\nVerifying integrity...")
    results = service.verify_integrity()
    for node, status in results.items():
        print(f"{node}: {status}")

    print("\n--- Simulating corruption in node2 ---")
    service.simulate_corruption("node2")

    print("\nVerifying integrity after corruption...")
    results = service.verify_integrity()
    for node, status in results.items():
        print(f"{node}: {status}")

    print("\n--- Restoring node2 from source ---")
    service.restore_node_from_source("node2")

    print("\nVerifying integrity after restore...")
    results = service.verify_integrity()
    for node, status in results.items():
        print(f"{node}: {status}")
